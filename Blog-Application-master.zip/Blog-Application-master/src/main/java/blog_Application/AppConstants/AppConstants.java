package blog_Application.AppConstants;

import blog_Application.Paylaod.RoleDto;

public class AppConstants {

	
	public static final long ROLE_USER =1L;
	
	public static final long ROLE_ADMIN=2L;
}
